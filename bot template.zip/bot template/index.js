const {token} = require("./configs/token.json");
const {name} = require("./configs/name.json");
const server = require("discord.js");
const {responseTrigger, responseTrigger2, responseTrigger3, responseTrigger4, responseTrigger5, responseTrigger6, responseTrigger7, responseTrigger8, responseTrigger9, responseTrigger10} = require("./configs/commands/replies.json");
const  {response, response2, response3, response4, response5, response6, response7, response8, response9, response10 } = require("./configs/commands/replyTriggers.json");



const client = new server.Client({
    intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS", "MESSAGE_CONTENT", ],
    partials: ["CHANNEL", "MESSAGE"],

});


client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === "!test") {
        message.reply("Test successful")
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === "hello") {
        message.reply(`hello how are you?`)
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === "good") {
        message.reply(`thats good :)`)
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === "im good") {
        message.reply(`thats good :)`)
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === "<@1274436179361665075>") {
        message.reply(`${name} is speaking now, whats up `)
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger
    )) {
        message.reply
        (
            `${response}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger2
    )) {
        message.reply
        (
            `${response2}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger3
    )) {
        message.reply
        (
            `${response3}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger4
    )) {
        message.reply
        (
            `${response4}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger5
    )) {
        message.reply
        (
            `${response5}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger6
    )) {
        message.reply
        (
            `${response6}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger7
    )) {
        message.reply
        (
            `${response7}`
        )
    }
});


client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger8
    )) {
        message.reply
        (
            `${response8}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger9
    )) {
        message.reply
        (
            `${response9}`
        )
    }
});

client.on("messageCreate", async (message) => {
    if (message.content.toLocaleLowerCase() === 
    (
        responseTrigger10
    )) {
        message.reply
        (
            `${response10}`
        )
    }
});

client.login(token)
console.log(`${name} has connected to discord servers and is running all configs `)